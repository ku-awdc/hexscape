## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  eval=TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library("hexscape")

