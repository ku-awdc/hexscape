library(testthat)
library(hexscape)

test_check("hexscape")
