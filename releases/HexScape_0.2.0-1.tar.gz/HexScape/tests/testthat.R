library(testthat)
library(HexScape)

test_check("HexScape")
