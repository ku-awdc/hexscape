# HexScape
An R package for aggregation of spatial data into hexagonal patches using simple features
