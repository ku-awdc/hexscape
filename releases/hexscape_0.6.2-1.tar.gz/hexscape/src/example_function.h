/*
  
  This is an example function header file with definition in a separate compilation unit (cpp file)
  
*/

#ifndef EXAMPLE_FUNCTION_H
#define EXAMPLE_FUNCTION_H

#include <Rcpp.h>

double example_function(const double a, const double b);

#endif // EXAMPLE_FUNCTION_H
